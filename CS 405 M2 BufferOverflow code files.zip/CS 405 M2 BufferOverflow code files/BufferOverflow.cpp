// BufferOverflow.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iomanip>
#include <iostream>

int main()
{
  std::cout << "Buffer Overflow Example" << std::endl;

  const std::string account_number = "CharlieBrown42";
  char user_input[21]; // Increased the size to 21 to allow 20 characters + null terminator

  std::cout << "Enter a value: ";

  // Use std::cin.getline() to safely handle input and prevent overflow.
  std::cin.getline(user_input, sizeof(user_input));

  // Check if the input  is too many characters.
  if (std::cin.fail()) {
      std::cin.clear();
      std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n'); // Discards the remaining input past allowed characters
      std::cout << "Input exceeded the maximum allowed length" << std::endl;
  }

  std::cout << "You entered: " << user_input << std::endl;
  std::cout << "Account Number = " << account_number << std::endl;

  return 0;

}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
